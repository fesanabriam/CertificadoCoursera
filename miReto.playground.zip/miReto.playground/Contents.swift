//: Playground - noun: mini reto

// Nombre: Francisco Sanabria Pais: El Salvador

import UIKit

// declaro el rango para la leyenda Viva Swift
var rango = 30...40


// utilizo un for para recorrer los número del 1 al 100
for var i=1 ; i <= 100 ; i++ {
    
    // utilizo un switch para validar el rango
    switch  i{
    case rango:
        print("\(i)Viva Swift")
    default:
        if i % 5 == 0  {     // si el numero es divisible entre 5
            print("\(i)Bingo")
        } else if i % 2 == 0{     // si el numero es par siempre y cuando el residuo es cero
            print("\(i)par")
        } else if i % 2 != 0 { // si el numero es par siempre y cuando el residuo es diferente de cero
            print("\(i)impar")}}
}
